/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.examenejer2;

/**
 *
 * @author ramonfr
 */
public class Pajaro extends Mascota {
    private String especie;

    public Pajaro(String especie, String nombre) {
        super(nombre);
        this.especie = especie;
    }

    public Pajaro(String especie) {
        this.especie = especie;
    }
    
    public Pajaro() {
        this.especie = "Sin determinar";
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }
    
    @Override
    public String toString(){
        return "Perro: "+ super.getNombre()+" Especie: "+especie+";";
    }
}
